# expressions > 2023-08-25 12:10pm
https://universe.roboflow.com/yolov7-td05q/expressions-wuipk

Provided by a Roboflow user
License: CC BY 4.0

