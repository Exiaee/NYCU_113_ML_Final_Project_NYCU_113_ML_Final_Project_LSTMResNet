# Ethnicity > 2023-09-10 11:46am
https://universe.roboflow.com/university-of-salford-mftj1/ethnicity-gj5xp

Provided by a Roboflow user
License: CC BY 4.0

